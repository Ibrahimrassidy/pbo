const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const authRoutes = require('./routes/auth');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secret',
    saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
    if (!req.session.user && req.path !== '/auth/login' && req.path !== '/auth/register') {
        return res.redirect('/auth/login');
    } else if (req.session.user && req.path === '/') {
        return res.redirect('/auth/profile');
    }
    next();
});

app.use('/auth', authRoutes);

app.get('/', (req, res) => {
    if (req.session.user) {
        return res.redirect('/auth/profile');
    } else {
        return res.redirect('/auth/login');
    }
});

// Update Profile Route
app.post('/auth/update-profile', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/auth/login'); // Redirect ke login jika belum login
    }

    const userId = req.session.user.id;
    const { username, email, address, phone } = req.body;

    const query = "UPDATE users SET username = ?, email = ?, address = ?, phone = ? WHERE id = ?";
    db.query(query, [username, email, address, phone, userId], (err, result) => {
        if (err) {
            console.error('Error updating profile:', err);
            return res.status(500).send('Error updating profile');
        }

        // Update session setelah berhasil update
        req.session.user.username = username;
        req.session.user.email = email;
        req.session.user.address = address;
        req.session.user.phone = phone;

        // Redirect ke halaman profile untuk menampilkan data terbaru
        res.redirect('/auth/profile');
    });
});

app.get('/auth/edit-profile', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/auth/login');
    }
    const user = req.session.user;
    res.render('edit-profile', { user });
});

app.post('/auth/update-profile', (req, res) => {
    // Cek apakah user ada di sesi
    if (!req.session.user) {
        return res.redirect('/auth/login'); // Redirect jika user belum login
    }

    // Ambil user ID dari sesi
    const userId = req.session.user.id;

    // Log untuk debugging
    console.log('Updating profile for user ID:', userId);

    // Ambil data dari form
    const { username, email, address, phone } = req.body;

    // Query untuk mengupdate data user
    const query = "UPDATE users SET username = ?, email = ?, address = ?, phone = ? WHERE id = ?";
    db.query(query, [username, email, address, phone, userId], (err, result) => {
        if (err) {
            console.error('Error updating profile:', err);
            return res.status(500).send('Something went wrong!');
        }

        // Update data di session setelah update berhasil
        req.session.user.username = username;
        req.session.user.email = email;
        req.session.user.address = address;
        req.session.user.phone = phone;

        // Redirect ke halaman profil untuk menampilkan data terbaru
        res.redirect('/auth/profile');
    });
});



app.listen(3000, () => {
    console.log('Server running on port 3000');
});
